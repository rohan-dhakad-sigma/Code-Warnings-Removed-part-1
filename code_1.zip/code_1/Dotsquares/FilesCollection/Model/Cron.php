<?php
/**
 * Copyright © 2015 Dotsquares. All rights reserved.
 */

namespace Dotsquares\FilesCollection\Model;

class Cron extends \Magento\Framework\Model\AbstractModel
{

    public function methodName()
    {
        return $this;
    }
}
